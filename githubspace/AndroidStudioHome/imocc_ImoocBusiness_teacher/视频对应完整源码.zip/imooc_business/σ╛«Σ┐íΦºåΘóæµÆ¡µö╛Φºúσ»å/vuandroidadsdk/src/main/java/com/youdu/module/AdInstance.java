package com.youdu.module;

import java.util.ArrayList;

/**
 * @author: qndroid
 * @function: the ad module
 * @date: 16/6/1
 */
public class AdInstance {

    public ArrayList<AdValue> values;
    public String version;
}
