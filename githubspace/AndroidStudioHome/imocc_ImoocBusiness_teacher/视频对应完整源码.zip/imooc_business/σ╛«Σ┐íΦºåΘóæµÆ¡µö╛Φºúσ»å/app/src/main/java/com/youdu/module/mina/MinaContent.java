package com.youdu.module.mina;

import com.youdu.module.BaseModel;

import java.util.ArrayList;

/**
 * Created by renzhiqiang on 16/8/20.
 */
public class MinaContent extends BaseModel {

    public String key;
    public ArrayList<MinaMessage> values;
}
