package com.youdu.module.user;

import com.youdu.module.BaseModel;

/**
 * Created by renzhiqiang on 15/11/20.
 */
public class UserContent extends BaseModel {
    public String uid;
    public String nick;
    public String name;
    public String tick;
    public String identity;
    public String mobile;
    public String passwd;
    public String state;
    public int opened;
    public String email;
    public int emailVerified;
    public String addr;
    public int hasMarried;
    public String educate;
    public String work;
    public int hasInvest;
    public int risk;
    public int is_use_virtual;
    public String invite;
    public String parent;
    public int is_freeze;
    public String openid;
    public int is_member;
    public int sex;
}
