package com.youdu.module.search;

import com.youdu.module.BaseModel;

/**
 * @author: vision
 * @function:
 * @date: 16/8/12
 */
public class BaseSearchModel extends BaseModel {

    public String ecode;
    public String emsg;
    public SearchModel data;
}
