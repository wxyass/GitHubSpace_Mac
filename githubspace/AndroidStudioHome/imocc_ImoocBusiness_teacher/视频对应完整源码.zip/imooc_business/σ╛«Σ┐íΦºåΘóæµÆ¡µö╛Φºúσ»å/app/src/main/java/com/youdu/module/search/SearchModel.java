package com.youdu.module.search;

import com.youdu.module.BaseModel;

import java.util.ArrayList;

/**
 * @author: vision
 * @function:
 * @date: 16/8/12
 */
public class SearchModel extends BaseModel {

    public long uptime;
    public ArrayList<ProductModel> list;
}
