package com.bennyhuo.imooc.reflections

annotation class PoKo

@Target(AnnotationTarget.PROPERTY)
annotation class AnotherAnno